﻿using SnakeGame.ViewModels;
using System.Windows;

namespace SnakeGame
{
    /// <summary>
    /// Логика взаимодействия для StartWindow.xaml
    /// </summary>
    public partial class StartWindow : Window
    {
        public StartWindow()
        {
            InitializeComponent();
            DataContext = new StartWindowVM(this);
        }
    }
}
