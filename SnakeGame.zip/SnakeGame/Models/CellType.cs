﻿namespace SnakeGame.Models
{
    internal enum CellType
    {
        None,
        Snake,
        Food
    }
}
