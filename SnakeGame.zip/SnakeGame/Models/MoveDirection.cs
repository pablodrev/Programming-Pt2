﻿namespace SnakeGame.Models
{
    internal enum MoveDirection
    {
        Left,
        Right,
        Up,
        Down
    }
}
